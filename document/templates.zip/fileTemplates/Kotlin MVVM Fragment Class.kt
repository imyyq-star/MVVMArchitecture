#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
class ${NAME} : BaseFragment<Fragment${Xml_binding}Binding, ${Xml_vm}ViewModel> (
    R.layout.fragment_${fragment_xml}, BR.viewModel
) {
}