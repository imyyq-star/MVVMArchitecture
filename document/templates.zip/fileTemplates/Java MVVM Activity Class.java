#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import me.goldze.mvvmhabit.base.BaseActivity;

#parse("File Header.java")
public class ${NAME}Activity extends BaseActivity<Activity${Xml}Binding, ${Xml}ViewModel> {
    @Override
    public int initVariableId() {
        return R.layout.activity_${xml};
    }

    @Override
    public int initContentView() {
        return BR.viewModel;
    }
}