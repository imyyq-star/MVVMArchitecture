#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.imyyq.mvvm.base.ViewBindingBaseActivity;

public class ${NAME}Activity extends ViewBindingBaseActivity<Activity${NAME}Binding, ${NAME}ViewModel> {
    @NotNull
    @Override
    public Activity${NAME}Binding initBinding(@NotNull LayoutInflater inflater, @Nullable ViewGroup container) {
        return Activity${NAME}Binding.inflate(inflater);
    }
}