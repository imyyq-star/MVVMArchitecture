#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

import android.view.LayoutInflater
import android.view.ViewGroup
import com.imyyq.mvvm.base.ViewBindingBaseActivity

#end
class ${NAME} : ViewBindingBaseActivity<Activity${Xml}Binding, ${Xml}ViewModel>() {
    override fun initBinding(inflater: LayoutInflater, container: ViewGroup?) =
        Activity${Xml}Binding.inflate(inflater)
}