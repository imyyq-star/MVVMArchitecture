#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.imyyq.mvvm.base.DataBindingBaseActivity;

#parse("File Header.java")
public class ${NAME}Activity extends DataBindingBaseActivity<Activity${NAME}Binding, ${NAME}ViewModel> {
    public ${NAME}Activity() {
        super(R.layout.activity_${xml}, BR.viewModel);
    }
}