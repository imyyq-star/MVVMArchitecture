#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

import android.app.Application
import com.imyyq.mvvm.base.BaseModel
import com.imyyq.mvvm.base.BaseViewModel

#end
#parse("File Header.java")
class ${NAME}(app: Application) : BaseViewModel<BaseModel>(app) {
}