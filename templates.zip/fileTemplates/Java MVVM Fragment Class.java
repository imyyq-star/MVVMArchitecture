#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.imyyq.mvvm.base.DataBindingBaseFragment;

#parse("File Header.java")
public class ${NAME}Fragment extends DataBindingBaseFragment<Fragment${Xml}Binding, ${Xml}ViewModel> {
    public ${NAME}Fragment() {
        super(R.layout.fragment_${xml}, BR.viewModel);
    }
}