#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import me.goldze.mvvmhabit.base.DataBindingBaseFragment;

#parse("File Header.java")
public class ${NAME}Fragment extends DataBindingBaseFragment<Fragment${Xml}Binding, ${Xml}ViewModel> {
    @Override
    public int initVariableId() {
        return BR.viewModel;
    }

    @Override
    public int initContentView() {
        return R.layout.fragment_${xml};
    }
}