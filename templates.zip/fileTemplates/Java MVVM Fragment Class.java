#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import me.goldze.mvvmhabit.base.DataBindingBaseFragment;

#parse("File Header.java")
public class ${NAME}Fragment extends DataBindingBaseFragment<Fragment${Xml}Binding, ${Xml}ViewModel> {
    @Override
    public int initVariableId() {
        return R.layout.fragment_${xml};
    }

    @Override
    public int initContentView() {
        return BR.viewModel;
    }
}