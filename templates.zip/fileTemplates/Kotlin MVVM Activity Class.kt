#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
class ${NAME} : DataBindingBaseActivity<Activity${Xml_binding}Binding, ${Xml_vm}ViewModel> (
    R.layout.activity_${activity_xml}, BR.viewModel
) {
}