#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

import android.view.LayoutInflater
import android.view.ViewGroup
import com.imyyq.mvvm.base.ViewBindingBaseFragment

#end
class ${NAME} : ViewBindingBaseFragment<Fragment${Xml}Binding, ${Xml}ViewModel>() {
    override fun initBinding(inflater: LayoutInflater, container: ViewGroup?) =
        Fragment${Xml}Binding.inflate(inflater)
}