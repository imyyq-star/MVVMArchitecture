#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import android.app.Application;

import androidx.annotation.NonNull;

import me.goldze.mvvmhabit.base.BaseViewModel;

#parse("File Header.java")
public class ${NAME}ViewModel extends BaseViewModel {
    public ${NAME}ViewModel(@NonNull Application application) {
        super(application);
    }
}