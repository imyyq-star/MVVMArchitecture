#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import android.app.Application;

import androidx.annotation.NonNull;

import com.imyyq.mvvm.base.BaseViewModel;
import com.imyyq.mvvm.base.BaseModel;

#parse("File Header.java")
public class ${NAME}ViewModel extends BaseViewModel<BaseModel> {
    public ${NAME}ViewModel(@NonNull Application application) {
        super(application);
    }
}