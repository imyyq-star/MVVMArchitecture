#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.imyyq.mvvm.base.ViewBindingBaseFragment;

public class ${NAME}Fragment extends ViewBindingBaseFragment<Fragment${NAME}Binding, ${NAME}ViewModel> {
    @NotNull
    @Override
    public Fragment${NAME}Binding initBinding(@NotNull LayoutInflater inflater, @Nullable ViewGroup container) {
        return Fragment${NAME}Binding.inflate(inflater);
    }
}